from django.apps import AppConfig


class FoldernameConfig(AppConfig):
    name = 'foldername'
